import SwiftUI

@main
struct VibrationTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
