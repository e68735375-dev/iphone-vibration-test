import SwiftUI
import UIKit
import CoreHaptics

@MainActor
final class HapticTester: ObservableObject {
    @Published var isPlaying = false
    @Published var message: String?

    let supportsHaptics = CHHapticEngine.capabilitiesForHardware().supportsHaptics
    private var engine: CHHapticEngine?
    private var player: CHHapticAdvancedPatternPlayer?
    private var sessionID = UUID()

    func impact(_ style: UIImpactFeedbackGenerator.FeedbackStyle) {
        stop()
        let generator = UIImpactFeedbackGenerator(style: style)
        generator.prepare()
        generator.impactOccurred()
    }

    func notification(_ type: UINotificationFeedbackGenerator.FeedbackType) {
        stop()
        let generator = UINotificationFeedbackGenerator()
        generator.prepare()
        generator.notificationOccurred(type)
    }

    func startPulse() {
        let events = (0..<30).map { index in
            CHHapticEvent(eventType: .hapticTransient, parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 1),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.5)
            ], relativeTime: Double(index) * 0.5)
        }
        play(events, message: "Пульсация остановится автоматически через 15 секунд.")
    }

    func startSpring() {
        let times: [Double] = [0, 0.12, 0.27, 0.45, 0.66, 0.90, 1.17]
        let events = times.enumerated().map { index, time in
            CHHapticEvent(eventType: .hapticTransient, parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: Float(1.0 - Double(index) * 0.12)),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.6)
            ], relativeTime: time)
        }
        play(events, message: nil)
    }

    private func play(_ events: [CHHapticEvent], message: String?) {
        stop()
        guard supportsHaptics else {
            self.message = "На этом устройстве тактильные эффекты недоступны. Проверяйте на iPhone."
            return
        }

        do {
            let currentSession = UUID()
            sessionID = currentSession
            let engine = try CHHapticEngine()
            self.engine = engine
            engine.stoppedHandler = { [weak self] _ in
                Task { @MainActor in
                    guard let self = self, self.sessionID == currentSession else { return }
                    self.isPlaying = false
                }
            }
            engine.resetHandler = { [weak self] in
                Task { @MainActor in
                    guard let self = self, self.sessionID == currentSession else { return }
                    self.isPlaying = false
                    self.message = "Вибрация прервана системой. Нажмите кнопку ещё раз."
                }
            }
            try engine.start()
            let pattern = try CHHapticPattern(events: events, parameters: [])
            let player = try engine.makeAdvancedPlayer(with: pattern)
            self.player = player
            player.completionHandler = { [weak self] _ in
                Task { @MainActor in
                    guard let self = self, self.sessionID == currentSession else { return }
                    self.isPlaying = false
                    self.message = nil
                }
            }
            try player.start(atTime: CHHapticTimeImmediate)
            isPlaying = true
            self.message = message
        } catch {
            stop()
            self.message = "Не удалось запустить вибрацию: \(error.localizedDescription)"
        }
    }

    func stop() {
        sessionID = UUID()
        try? player?.stop(atTime: CHHapticTimeImmediate)
        player = nil
        engine?.stop(completionHandler: nil)
        engine = nil
        isPlaying = false
        message = nil
    }
}

struct ContentView: View {
    @StateObject private var tester = HapticTester()
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 8) {
                        Image(systemName: "iphone.radiowaves.left.and.right")
                            .font(.system(size: 42))
                            .foregroundColor(.accentColor)
                            .accessibilityHidden(true)
                        Text("Проверьте вибрацию")
                            .font(.largeTitle.bold())
                        Text("Нажмите на кнопку и почувствуйте отклик iPhone.")
                            .foregroundColor(.secondary)
                    }

                    if !tester.supportsHaptics {
                        Label("Тактильные эффекты недоступны на этом устройстве.", systemImage: "exclamationmark.triangle")
                            .foregroundColor(.orange)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Сила отклика").font(.headline)
                        HStack(spacing: 8) {
                            impactButton("Слабый", .light)
                            impactButton("Средний", .medium)
                            impactButton("Сильный", .heavy)
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Уведомления").font(.headline)
                        HStack(spacing: 8) {
                            notificationButton("Успех", .success)
                            notificationButton("Внимание", .warning)
                            notificationButton("Ошибка", .error)
                        }
                    }

                    HStack(spacing: 18) {
                        SpringShape()
                            .stroke(Color.accentColor, style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
                            .frame(width: 48, height: 76)
                            .accessibilityHidden(true)
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Пружина").font(.headline)
                            Text("Короткая серия затухающих импульсов.")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            Button("Проверить пружину") { tester.startSpring() }
                                .buttonStyle(.bordered)
                                .disabled(!tester.supportsHaptics)
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Пульсация").font(.headline)
                        Text("Серия импульсов длится до 15 секунд. Можно остановить её в любой момент.")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        Button(tester.isPlaying ? "Остановить" : "Начать пульсацию") {
                            if tester.isPlaying { tester.stop() } else { tester.startPulse() }
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(!tester.supportsHaptics)
                    }

                    if let message = tester.message {
                        Text(message).font(.footnote).foregroundColor(.secondary)
                    }
                    Text("Проверяйте на настоящем iPhone: симулятор не воспроизводит вибрацию.")
                        .font(.footnote).foregroundColor(.secondary)
                }
                .padding(20)
                .frame(maxWidth: 600, alignment: .leading)
            }
            .navigationTitle("Тест вибрации")
            .navigationBarTitleDisplayMode(.inline)
        }
        .onChange(of: scenePhase) { phase in
            if phase != .active { tester.stop() }
        }
    }

    private func impactButton(_ title: String, _ style: UIImpactFeedbackGenerator.FeedbackStyle) -> some View {
        Button(title) { tester.impact(style) }
            .buttonStyle(.bordered)
            .frame(maxWidth: .infinity)
            .disabled(!tester.supportsHaptics)
    }

    private func notificationButton(_ title: String, _ type: UINotificationFeedbackGenerator.FeedbackType) -> some View {
        Button(title) { tester.notification(type) }
            .buttonStyle(.bordered)
            .frame(maxWidth: .infinity)
            .disabled(!tester.supportsHaptics)
    }
}

// Декоративное изображение пружины: не отражает физические свойства мотора.
private struct SpringShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = rect.midX
        path.move(to: CGPoint(x: center, y: rect.minY))
        path.addLine(to: CGPoint(x: center, y: rect.height * 0.1))
        for step in 0...100 {
            let progress = Double(step) / 100
            let x = center + rect.width * 0.38 * CGFloat(sin(progress * .pi * 10))
            let y = rect.height * (0.1 + 0.8 * CGFloat(progress))
            path.addLine(to: CGPoint(x: x, y: y))
        }
        path.addLine(to: CGPoint(x: center, y: rect.maxY))
        return path
    }
}
